<div class="footer">
    
    <?php
        wp_nav_menu(
             array(
                'menu'=> 'footer',
                'container'=>'',
                'theme_location'=>'footer',
                'container_class'=> 'raka-menu-item'
                )
        );
    ?>
    <h6 class="copy-right">© <?php echo date('Y');?>  Raka. All Rights Reserved</h6>
</div>

<h6 class="copy-right">© <?php echo date('Y');?>  Raka. All Rights Reserved</h6>

<?php
    wp_footer();
?>

</body>
</html>