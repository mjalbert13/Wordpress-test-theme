function hello(){
    console.log("hello world")
}

hello();