<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <?php
    wp_head();
    ?>
</head>
<body>
    <header >
    <div class="nav">

        <div class="logo-section">
            <?php
                $custom_logo_id = get_theme_mod( 'custom_logo' );
                $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                $home = get_home_url();
                 
                if ( has_custom_logo() ) {
                    echo '<img href="' . $home .'" class="header-logo" src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '">';
                } else {
                    echo '<h1>' . get_bloginfo('name') . '</h1>';
                }
            ?>
        </div >
        <div class="nav-menu">

        <?php
        
            wp_nav_menu(
                array(
                    'menu'=> 'primary',
                    'container'=>'',
                    'theme_location'=>'primary',
                    'container_class'=> 'raka-menu-item'
                )
            );
        ?>
        </div>
    </div>
    </header>
